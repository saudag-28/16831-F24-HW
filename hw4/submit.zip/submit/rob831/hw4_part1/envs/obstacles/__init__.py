from rob831.hw4_part1.envs.obstacles.obstacles_env import Obstacles
